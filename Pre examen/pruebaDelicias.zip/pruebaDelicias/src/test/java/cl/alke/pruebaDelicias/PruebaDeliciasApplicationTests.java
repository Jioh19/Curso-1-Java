package cl.alke.pruebaDelicias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaDeliciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
