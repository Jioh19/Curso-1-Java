package cl.alke.delicias3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Delicias3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
