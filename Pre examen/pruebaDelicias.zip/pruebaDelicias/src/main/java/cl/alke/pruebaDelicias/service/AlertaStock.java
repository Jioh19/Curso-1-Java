package cl.alke.pruebaDelicias.service;

public interface AlertaStock {
    void alertar();
}
