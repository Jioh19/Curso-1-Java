package cl.alke.bike69.controller;

import cl.alke.bike69.service.BrandService;
import cl.alke.bike69.service.Categoryservice;
import cl.alke.bike69.service.StoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class Inicio {

    @Autowired
    StoreService storeService;
    @Autowired
    Categoryservice categoryservice;
    @Autowired
    BrandService brandService;

    @GetMapping("/")
    public String index(Model model) {

        List<String> stores = storeService.getTienda();
        List<String> categories = categoryservice.getCategoria();
        List<String> brands = brandService.getBrand();
        model.addAttribute("stores", stores);
        model.addAttribute("categories", categories);
        model.addAttribute("brands", brands);
        return "index";
    }
}
