package cl.alke.bike69;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bike69Application {

	public static void main(String[] args) {
		SpringApplication.run(Bike69Application.class, args);
	}

}
