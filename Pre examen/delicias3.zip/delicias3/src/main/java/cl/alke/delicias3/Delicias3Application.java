package cl.alke.delicias3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Delicias3Application {

	public static void main(String[] args) {
		SpringApplication.run(Delicias3Application.class, args);
	}

}
