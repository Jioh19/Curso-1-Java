package cl.alke.pruebaDelicias.niveles;

public interface Nivel {
    String categoria();
    String beneficio();
}
